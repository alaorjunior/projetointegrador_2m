const Home = () => {
    return (
        <>
            <section>
                <h1>Consulta de Despesas Publicas</h1>
            </section>
            <section>
                <div className="section1">
                    <h2>Voce sabe o que é Despesas Publicas?</h2>
                    <p>text</p>
                </div>
            </section>
            <section>
                <div className="section2">
                    <h2>Proposito</h2>
                    <p>text</p>
                </div>
            </section>
        </>
    );
}

export default Home;